function enter(pi) {
    pi.teleport(6);
}