function enter(pi) {
   pi.warp(993001000)
}