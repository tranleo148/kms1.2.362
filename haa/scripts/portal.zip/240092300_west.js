function enter(pi) {
                  pi.warp(240092400, 0);
if (pi.getQuestStatus(31348) == 1) {
                  pi.openNpc(2210010);
}
	pi.playPortalSE();    
}
