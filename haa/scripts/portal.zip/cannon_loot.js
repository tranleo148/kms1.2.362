function enter(pi) {
    if (pi.getQuestStatus(2564) == 2) {
	pi.ShowWZEffect("UI/tutorial.img/21");
    }
}