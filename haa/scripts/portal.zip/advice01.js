function enter(pi) {
    pi.showInstruction("Click \r\\#b<Heena>#k", 100, 5);
}