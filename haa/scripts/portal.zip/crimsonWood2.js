function enter(pi) {
	pi.warp(301020000, "sp");
	pi.playPortalSE();    
}
