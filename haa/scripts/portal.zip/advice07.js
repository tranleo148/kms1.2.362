function enter(pi) {
    pi.showInstruction("Press #e#b[W]#k#n to view the World Map.", 250, 5);
}