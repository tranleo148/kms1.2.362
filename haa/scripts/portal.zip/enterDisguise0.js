function enter(pi) {
    pi.warp(130010000,0);
}
