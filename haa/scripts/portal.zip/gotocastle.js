
function enter(pi) {
	pi.playPortalSE();
	pi.warp(106020501);
        return true;
}