function enter(pi) {
    pi.warp(100030200, "east00");
    return true;
}  