function enter(pi) {
    pi.warp(123456789);
    return false;
}