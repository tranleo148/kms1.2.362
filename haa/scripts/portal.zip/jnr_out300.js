function enter(pi) {
    pi.warpParty(926110400);
}