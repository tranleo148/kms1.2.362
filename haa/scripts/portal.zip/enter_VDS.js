function enter(pi) {
    pi.warp(105010000,0);
}