function enter(pi) {
	pi.warp(301040000, 1);
	pi.playPortalSE();    
}
