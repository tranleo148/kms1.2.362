function enter(pi) {
    pi.warp(100030102, "in00");
    return true;
}  