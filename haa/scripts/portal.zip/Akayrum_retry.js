/*
 *  ����
 */

function enter(pi) {
    pi.warp(272020200);
    return false;
}