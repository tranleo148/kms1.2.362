function enter(pi) {
	pi.warp(301030000, 0);
	pi.playPortalSE();    
}
