function enter(pi) {
    pi.teleport(1);
}