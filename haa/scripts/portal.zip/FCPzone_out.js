function enter(pi) {
	pi.warp(301000000, 0);
	pi.playPortalSE();    
}
