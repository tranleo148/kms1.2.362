function enter(pi) {
    pi.warp(680000715,0);
}