function enter(pi) {
    pi.playerMessage("This portal is not available yet.");
}