function enter(pi) {
     pi.warp(100000000);
    return true;
}