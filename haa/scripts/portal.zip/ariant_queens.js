//some quest where you must use hidden portals
function enter(pi) {
}