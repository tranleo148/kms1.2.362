function enter(pi) {
    pi.openNpcCustom(pi.getClient(), 2183001, "connect_UIOpen");
    return false;
}