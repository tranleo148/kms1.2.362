function enter(pi) {
    pi.warp(900020100,0);
}