function enter(pi) {
    pi.openNpc(2190001);
}