function enter(pi) {
    pi.warp(926110200,"in00");
}