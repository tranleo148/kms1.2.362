function enter(pi) {
    pi.warp(1000000);
}