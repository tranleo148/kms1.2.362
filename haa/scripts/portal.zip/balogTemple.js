function enter(pi) {
    pi.playPortalSE();
    pi.warp(105100000, 2);
}