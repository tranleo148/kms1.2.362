/*
 * 
 */

function enter(pi) {

        pi.openNpc(2007, "JinHillahOut")
        return true;

}