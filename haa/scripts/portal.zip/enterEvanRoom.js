function enter(pi) {
    pi.warp(100030100);
    return true;
}  