function enter(pi) {
    pi.warp(301050300, 0);
    return true;
}