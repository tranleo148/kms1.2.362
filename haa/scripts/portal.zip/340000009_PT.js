function enter(pi) {
	pi.warp(340000100);
}
