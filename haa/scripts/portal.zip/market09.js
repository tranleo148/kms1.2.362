function enter(pi) {
    pi.saveLocation("FREE_MARKET");
    pi.warp(910000000,"out00");
}
