var status = -1;

function enter(pi) {
	pi.openNpc(2400025);
} 