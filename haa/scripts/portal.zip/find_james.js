function enter(pi) {
    pi.playerMessage(5, "Unavailable.");
}