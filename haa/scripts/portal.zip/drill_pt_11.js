function enter(pi) {
    pi.teleport(12);
}