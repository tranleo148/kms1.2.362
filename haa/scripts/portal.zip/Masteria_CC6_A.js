
function enter(pi) {
    pi.playPortalSE();
    pi.warp(610020010, "CC1_A");
}