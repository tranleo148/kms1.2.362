function enter(pi) {
    pi.openNpc(9000233, "flag_goal");   
}