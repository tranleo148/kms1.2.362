function enter(pi) {
        pi.warp(300010420,1);
pi.getPlayer().getMap().respawn(true);
    return true;
}