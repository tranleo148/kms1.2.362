function enter(pi) {
	
	pi.openNpc(9010000, "LudiElevator");
	return true;
}