function enter(pi) {
    pi.warp(912060100,0);
}