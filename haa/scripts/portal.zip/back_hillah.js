function enter(pi) {
	pi.warp(pi.getPlayer().getMapId() - 10);
}