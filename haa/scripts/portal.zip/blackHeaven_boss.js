function enter(pi) {
    pi.openNpcCustom(pi.getClient(), 3003608, "blackHeaven_boss")
}