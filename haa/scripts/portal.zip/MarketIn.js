function enter(pi) {
	pi.openNpc(9000083);
}