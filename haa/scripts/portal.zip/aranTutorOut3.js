function enter(pi) {
    pi.teachSkill(20000016,0,-1);
    pi.teachSkill(20000016,1,0);
    pi.warp(914000220,1);
    pi.send(MainPacketCreator.showEffect("aran/tutorialGuide3/0"));
}