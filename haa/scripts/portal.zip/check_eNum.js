function enter(pi) {
    pi.openNpcCustom(pi.getClient(), 2144017, "check_eNum");
    return true;
}