/*
 *  ����
 */

function enter(pi) {
    pi.openNpc(2144018);
    return false;
}