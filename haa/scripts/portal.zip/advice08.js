function enter(pi) {
    pi.showInstruction("Press #e#b[S]#k#n to view your character information.", 250, 5);
}