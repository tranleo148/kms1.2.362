function enter(pi) {
    pi.teleport(10);
}