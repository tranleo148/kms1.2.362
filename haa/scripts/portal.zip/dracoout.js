function enter(pi) {
    pi.warp(240000100, "east00")
}