


function enter(pi) {
    pi.playPortalSE();
    pi.warp(104020120,2);
    return true;
}