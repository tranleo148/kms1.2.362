function enter(pi) {
    if (pi.getQuestStatus(2369) == 1 && !pi.haveItem(4032617)) { //too lazy to do the map shit
	pi.gainItem(4032617,1);
    }
}