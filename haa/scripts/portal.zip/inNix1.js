function enter(pi) {
	pi.warp(240020600,0);
}