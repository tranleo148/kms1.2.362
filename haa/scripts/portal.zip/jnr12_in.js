function enter(pi) {
    pi.warp(926110401,0);
}