function enter(pi) {
    pi.warp(223010110,0);
}