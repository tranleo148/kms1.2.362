function enter(pi) {
    pi.openNpc(2192001);
}