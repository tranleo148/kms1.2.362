function enter(pi) {
    pi.playPortalSE();
    pi.warp(260000301, "out00");
}