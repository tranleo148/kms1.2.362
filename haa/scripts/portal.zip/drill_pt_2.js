function enter(pi) {
    pi.teleport(3);
}