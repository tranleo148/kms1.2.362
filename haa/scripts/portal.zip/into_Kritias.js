function enter(pi) {
	switch(pi.getPlayer().getMapId()) {
		case 241020200:
		pi.warp(241020100, "center00");
		break;

		case 241010200:
		pi.warp(241010100, "center00");
		break;

		case 241000200:
		pi.warp(241000100, "center00");
		break;

		case 241020210:
		pi.warp(241020110, "center00");
		break;

		case 241010210:
		pi.warp(241010110, "center00");
		break;

		case 241000210:
		pi.warp(241000110, "center00");
		break;

		case 241020220:
		pi.warp(241020120, "center00");
		break;

		case 241010220:
		pi.warp(241010120, "center00");
		break;

		case 241000220:
		pi.warp(241000120, "center00");
		break;

	}
}