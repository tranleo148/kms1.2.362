function enter(pi) {
    pi.playPortalSE();
    pi.warp(310000004, 1);
    return true;
}