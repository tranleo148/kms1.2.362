function enter(pi) {
    pi.openNpcCustom(pi.getClient(),2008,"bossBlackMage_pt");
}