function enter(pi) {
    pi.warp(140000000,0);
}