function enter(pi) {
    pi.playPortalSE();
    pi.warp(310000010, 1);
    return true;
}