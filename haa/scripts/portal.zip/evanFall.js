function enter(pi) {
    pi.warp(900090102,0);
}