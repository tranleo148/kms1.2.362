function enter(pi) {
    pi.warp(900090100,0);
}