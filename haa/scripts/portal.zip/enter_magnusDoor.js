function enter(pi) {
    pi.openNpc(3001020);
}