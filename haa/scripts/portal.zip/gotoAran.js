function enter(pi) {
    pi.warp(927020050, 0);
}