function enter(pi) {
	if (pi.getPlayer().getMapId() == 809060000) {
	    pi.warp(950100000,0);
	} else {
	    pi.warp(809060000,0);
	}
}