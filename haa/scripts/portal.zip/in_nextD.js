function enter(pi) {
    if (pi.pi.getQuestStatus(31144) == 1) {
	pi.forceCompleteQuest(31144);
    }
}