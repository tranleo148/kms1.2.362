function enter(pi) {
	pi.openNpcCustom(pi.getClient(), 1540446, "bh_bossOut");
}