function enter(pi) {
    pi.openNpc(9010049,"enter_house");
}