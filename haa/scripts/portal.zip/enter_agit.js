function enter(pi) {
    pi.warp(200100010, 0);
}