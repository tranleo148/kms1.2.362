function enter(pi) {
	pi.ShowWZEffect("UI/tutorial.img/26");
	return true;
}