function enter(pi) {
    pi.openNpcCustom(pi.getClient(), 2184000,"hillah_next")
}