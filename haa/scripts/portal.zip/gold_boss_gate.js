function enter(pi) {
            if (pi.getQuestStatus(3864) != 0) {
                 pi.warp(252030000,1);
                pi.dispose();
                return;
} else {
        pi.warp(252020700,1);
}
    return true;
}