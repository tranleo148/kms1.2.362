function enter(pi) {
    pi.warp(106021000,0);
}