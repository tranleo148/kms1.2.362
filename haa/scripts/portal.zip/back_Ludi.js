function enter(pi) {
    pi.warp(220000000,0);
}