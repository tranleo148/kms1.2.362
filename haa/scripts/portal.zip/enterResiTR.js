function enter(pi) {
	pi.MovieClipIntroUI(false);
	 pi.showWZEffect("Effect/OnUserEff.img/guideEffect/evanTutorial/evanBalloon60",0);
	return true;
}