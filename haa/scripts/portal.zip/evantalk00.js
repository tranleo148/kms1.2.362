function enter(pi) {
    pi.showWZEffect("Effect/OnUserEff.img/guideEffect/evanTutorial/evanBalloon00",1);
}