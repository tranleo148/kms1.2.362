function enter(pi) {
	pi.warp(401060000);
}